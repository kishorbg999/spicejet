package vishalmain;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
	
	public static WebDriver driver;
	
	
	protected SearchPage searcht;
	protected WebDriverWait wait;
}
